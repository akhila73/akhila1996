use PoojithaDatabase
go

create table ParticipantNew
(
VoucherNumber varchar(25)  primary key,
ParticipantName varchar(25) unique not null,
Technology varchar(250) null,
CertificationCode varchar(250) not null,
CertificationName varchar(250) not null,
PDandT datetime 
)
drop table ParticipantNew


insert into Participant values('ABCD-1234-1345-6789','Poojitha','Microsoft','70-461','Quering Microsoft','1/2/1234') 
insert into Participant values('ABCD-8907-6789-6789','lakshmi','Microsoft','70-462','Quering Microsoft1','1/6/1234') 
insert into Participant values('ABCD-3456-1345-6789','tharun','Microsoft','70-463','Quering Microsoft2','1/9/1234') 
insert into Participant values('ABCD-3456-4567-6789','Poojitha Annam','Microsoft','70-464','Quering Microsoft3','1/8/1234') 
select * from Participant
CREATE procedure Participants.usp_AddParticipant
@pvoucher varchar,
@pName varchar,
@pTech varchar,
@pCertificate varchar,
@pCName varchar,
@pDandT datetime
As
BEGIN
insert into Participant values(@pvoucher,@pName,@pTech,@pCertificate,@pCName,@pDandT)
END
create proc Participants.usp_SearchParticipant
(
@pId int
)
as
begin
	select * from Participant
	where VoucherName = @pvoucher
end