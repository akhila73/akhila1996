﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using PLMEntity;
using PLMDAL;
using System.Web.RegularExpressions;
using ExceptionLayer;

namespace PLMBLayer
{
    public class Validations
    {
        ParticipantValidation participant;
        public DataTable GetParticipant_BLL()
        {
            DataTable dtparticipant;
            try
            {
                participant = new ParticipantValidation();
                dtparticipant = participant.GetParticipant_DAL();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return dtparticipant;
        }
        public bool validateP(Participant newP)
        {
            bool isValidP = true;
            StringBuilder sbError = new StringBuilder();
            try
            {

               
                int r1, r2, r3,r4;
               
                string VoucherNumber = Console.ReadLine();
                for (int i = 0; i < 4; i++)
                {
                  
                    string a = VoucherNumber;
                    if (!char.IsUpper(newP.VoucherNumber[i]))
                    {
                        sbError.Append("enter first four letters in CAPSLOCK");
                    }
                }
                    Random r = new Random();
                r1 = r.Next(1000, 9999);
                r2 = r.Next(1000, 9999);
                r3 = r.Next(1000, 9999);
                r4 = r.Next(1000, 9999);
                newP.VoucherNumber = newP.VoucherNumber[0] + newP.VoucherNumber[1] + newP.VoucherNumber[2] + newP.VoucherNumber[3] + "-" + r1 + "-" + r2 + "-" + r3 + "-" + r4;


            }
            catch (ParticipantException ex)
            { throw ex; }
            catch (SystemException ex)
            {

                throw ex;
            }

            return isValidP;
        }
        public int AddParticipant_BLL(Participant newP)
        {
            int rowsAffected = 0;
            ParticipantValidation operationObj;
            try
            {
                if (validateP(newP))
                {
                    operationObj = new ParticipantValidation();
                    rowsAffected = operationObj.AddParticipant_DAL(newP);
                }
            }
            catch (ParticipantException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (SystemException ex)
            {

                throw ex;
            }
            return rowsAffected;

        }
        public Participant Search(int productId)
        {
            try
            {
                ParticipantValidation pd = new ParticipantValidation();
                return pd.Search(productId);
            }
            catch (ParticipantException)
            {
                throw;
            }
        }
        public DataTable Display()
        {
            try
            {
                ParticipantValidation pd = new ParticipantValidation();
                return pd.Display();
            }
            catch (ParticipantException)
            {
                throw;
            }
        }
    }
}
