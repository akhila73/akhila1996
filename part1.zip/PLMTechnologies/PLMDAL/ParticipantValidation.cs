﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using PLMEntity;
using ExceptionLayer;

namespace PLMDAL
{
    public class ParticipantValidation
    {
        static string PConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection PConnObj;
        SqlCommand PCommand;
        DataTable dtparticipant;
        SqlDataReader PReader = null;
        public ParticipantValidation()
        {
            PConnObj = new SqlConnection();
            PConnObj.ConnectionString = PConnStr;
        }
        public int AddParticipant_DAL(Participant d)
        {
            int rowsAffected = 0;
            try
            {
                PCommand = new SqlCommand("Participants.usp_AddParticipant", PConnObj);
                PCommand.CommandType = CommandType.StoredProcedure;
                PCommand.Parameters.AddWithValue("@pvoucher", d.VoucherNumber);
                PCommand.Parameters.AddWithValue("@pName", d.ParticipantName);
                PCommand.Parameters.AddWithValue("@pTech", d.Technology);
                PCommand.Parameters.AddWithValue("@pCertificate", d.CertificationCode);
                PCommand.Parameters.AddWithValue("@pCName", d.CertificationName);
                PCommand.Parameters.AddWithValue("@pDandT", d.PDandT);

                PConnObj.Open();
                rowsAffected = PCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                if (PConnObj.State == ConnectionState.Open) PConnObj.Close();
            }
            return rowsAffected;
        }
        public DataTable GetParticipant_DAL()
        {
            try
            {
                dtparticipant = new DataTable();
                PCommand = new SqlCommand("Participants.usp_SearchParticipant", PConnObj);
                PCommand.CommandType = CommandType.StoredProcedure;
                PConnObj.Open();
                PReader = PCommand.ExecuteReader();
                if (PReader.HasRows)
                {
                    dtparticipant.Load(PReader);
                }
            }
            catch (SqlException ex)
            {

                throw;
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                PReader.Close();
                if (PConnObj.State == ConnectionState.Open) PConnObj.Close();
            }
            return dtparticipant;
        }
        public Participant Search(int productId)
        {
            Participant p = null;

            try
            {
                //  con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                PCommand = new SqlCommand();
                PCommand.CommandText = "Participants.uspSearchProduct";
                PCommand.Connection = PConnObj;
                PCommand.CommandType = CommandType.StoredProcedure;
                PCommand.Parameters.AddWithValue("@pId", productId);

                PConnObj.Open();
                SqlDataReader dr = PCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    p = new Participant
                    {
                        VoucherNumber = dr["VoucherNumber"].ToString(),
                        ParticipantName = dr["ParticipantName"].ToString(),
                        Technology = dr["Technology"].ToString(),
                        CertificationCode = dr["CertificationCode"].ToString(),
                        CertificationName = dr["CertificationName"].ToString(),
                        PDandT = DateTime.Parse(dr["PDandT"].ToString())
                    };
                    dr.Close();
                }
            }

            catch (ParticipantException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (PConnObj.State == ConnectionState.Open)
                {
                    PConnObj.Close();
                }
            }
            return p;
        
        }
        public DataTable Display()
        {
            DataTable dt = null;

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                PCommand = new SqlCommand();
                PCommand.CommandText = "Participants.uspGetProducts";
                PCommand.Connection = PConnObj;
                PCommand.CommandType = CommandType.StoredProcedure;

                PConnObj.Open();
                SqlDataReader dr = PCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (ParticipantException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (PConnObj.State == ConnectionState.Open)
                {
                    PConnObj.Close();
                }
            }
            return dt;
        }
    }
}
