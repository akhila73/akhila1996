﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLMEntity
{
    public class Participant
    {
        public string VoucherNumber { get; set; }
        public string ParticipantName { get; set; }
        public string Technology { get; set; }
        public string CertificationCode { get; set; }
        public string CertificationName { get; set; }
        public DateTime PDandT { get; set; }
    }
}
