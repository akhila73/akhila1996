﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLayer
{
    public class ParticipantException:ApplicationException
    {
        public ParticipantException() : base()
        {

        }

        public ParticipantException(string errMessage) : base(errMessage)
        {

        }
    }
}
