﻿using ExceptionLayer;
using PLMBLayer;
using PLMEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PLMTechnologies
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void btnAddCategory_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Participant p = new Participant
                {
                    VoucherNumber = txtPName.Text,
                    ParticipantName = txtPName.Text,
                    Technology = txtTech.Text,
                    CertificationCode = txtCCode.Text,
                    CertificationName = txtCertificationName.Text
                };
                Validations pb = new Validations();
                int VoucherNumber = pb.AddParticipant_BLL(p);
                MessageBox.Show(string.Format("New Participant Added.\nVoucherNumber: {0}", VoucherNumber),
                    "Product Management System");
            }
            catch (ParticipantException ex)
            {
                MessageBox.Show(ex.Message, "Participant Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Participant Management System");
            }
        }

    }
}
