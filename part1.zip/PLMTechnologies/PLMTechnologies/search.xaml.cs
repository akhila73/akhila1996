﻿using ExceptionLayer;
using PLMBLayer;
using PLMEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLMTechnologies
{
    /// <summary>
    /// Interaction logic for search.xaml
    /// </summary>
    public partial class search : Window
    {
        public search()
        {
            InitializeComponent();
        }
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Validations pb = new Validations();
                Participant p = pb.Search(int.Parse(txtVoucherName.Text));
                if (p != null)
                {
                    txtVoucherName.Text = p.VoucherNumber;
                    txtPName.Text = p.ParticipantName;
                    
                    gb1.Visibility = Visibility.Visible;
                }
                else
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show
                        (string.Format("Participant with VoucherNumber {0} does not exists.", txtVoucherName.Text),
                        "Participant Management System");
                }
            }
            catch (ParticipantException ex)
            {
                MessageBox.Show(ex.Message, "Participant Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Participant Management System");
            }
        }
    }
}
