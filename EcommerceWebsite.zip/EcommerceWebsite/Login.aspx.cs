﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EcommerceWebsite
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack)
            {
                Label1.Visible = false;
            }

            if (Session["person"] != null)
            {
                if (Session["person"].ToString() == "admin")
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "admin" && TextBox2.Text == "admin" && CheckBox1.Checked)
            {
                HttpCookie c2 = new HttpCookie("MyCookie");
                c2["id"] = "admin";
                c2["pass"] = "admin";
                c2.Expires.Add(new TimeSpan(24, 0, 0));
                Response.Cookies.Add(c2);
                Session["person"] = c2["id"];
                Session.Timeout=1;
                Server.Transfer("SignUp.aspx");
            }
            else
            {

                Label1.Visible = true;
                Label1.Text = "Username or password is Incorrect!";


            }
        }
    }
}