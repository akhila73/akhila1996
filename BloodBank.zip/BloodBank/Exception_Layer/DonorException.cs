﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Layer
{
    public class DonorException : ApplicationException
    {
        public DonorException(): base()
        {

        }
        public DonorException(string Message): base(Message)
        {

        }
    }
}
