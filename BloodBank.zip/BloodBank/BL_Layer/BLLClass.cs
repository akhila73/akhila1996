﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity_Layer;
using Exception_Layer;

namespace BL_Layer
{
    public class BLLClass
    {
        public void AddDonorBLL(Entities.BloodDonor obj)
        {
            try
            {
                if(obj.MobileNo.Length!=10)
                {
                    throw new DonorException("Mobile number must be 10 digits");

                }
                

            }
            catch (DonorException ex)
            {

                throw ex;
            }
            catch(Exception)
            {
                throw;
            }
        }
        public void AddCampBLL(Entities.Camp camp)
        {
            try
            {

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
