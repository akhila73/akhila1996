﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BloodBank
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Page
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void btnlogin_Click(object sender, RoutedEventArgs e)
        {
            LoginPage objLoginPage = new LoginPage();
            this.NavigationService.Navigate(objLoginPage);
        }

        private void btnBDonor_Click(object sender, RoutedEventArgs e)
        {
            Blood_Donor_Page objBDonor = new Blood_Donor_Page();
            this.NavigationService.Navigate(objBDonor);
        }

        private void btnBDonationCamp_Click(object sender, RoutedEventArgs e)
        {
            BDonationCamp_Page objBDCamp = new BDonationCamp_Page();
            this.NavigationService.Navigate(objBDCamp);
        }

        private void btnBBank_Click(object sender, RoutedEventArgs e)
        {
            BloodBank_Page objBBank = new BloodBank_Page();
            this.NavigationService.Navigate(objBBank);
        }

        private void btnHospital_Click(object sender, RoutedEventArgs e)
        {
            Hospital_Page objHsp = new Hospital_Page();
            this.NavigationService.Navigate(objHsp);
        }

        private void btnBInventory_Click(object sender, RoutedEventArgs e)
        {
            BloodInventory_Page objInv = new BloodInventory_Page();
            this.NavigationService.Navigate(objInv);
        }
    }
}
