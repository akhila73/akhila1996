﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BL_Layer;
using Entity_Layer;


namespace BloodBank
{
    /// <summary>
    /// Interaction logic for Blood_Donor_Page.xaml
    /// </summary>
    public partial class Blood_Donor_Page : Page
    {
        public Blood_Donor_Page()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            cmbBloodGroup.Items.Add("O +");
            cmbBloodGroup.Items.Add("B +");
            cmbBloodGroup.Items.Add("A +");
            cmbBloodGroup.Items.Add("AB +");
            cmbBloodGroup.Items.Add("O -");
            cmbBloodGroup.Items.Add("B -");
            cmbBloodGroup.Items.Add("A -");
            cmbBloodGroup.Items.Add("AB -");
        }

        private void btn_AddDonor_Click(object sender, RoutedEventArgs e)
        {
            Entities.BloodDonor blood = new Entities.BloodDonor();
            blood.BDonorId = txtBDonorId.Text;
            blood.Firstname = txtFirstName.Text;
            blood.LastName = txtLastName.Text;
            blood.MobileNo = txtMobileNo.Text;
            blood.Address = txtAddress.Text;
            blood.City = txtCity.Text;
            blood.BloodGroup = cmbBloodGroup.Text;
            BLLClass objAddDonor = new BLLClass();
            objAddDonor.AddDonorBLL(blood);
        }
    }
}
