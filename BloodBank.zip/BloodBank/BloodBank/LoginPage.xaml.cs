﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BloodBank
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        SqlCommand cmd = new SqlCommand();
        SqlConnection conn = new SqlConnection();
        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        public LoginPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool a;
                conn.ConnectionString = @"Data Source=192.168.14.101\sql2;Initial Catalog=BloodBankManagement;User ID=sa;Password=tvaksa#123";
                cmd.CommandText = "select * from Login_Data Where User_Id='" + txtLoginID.Text + "'and Password='" + txtPassword.Text + "'";

                cmd.Connection = conn;
                sda.SelectCommand = cmd;
                sda.Fill(dt);
                if (dt.Rows.Count>0)
                {
                    HomePage objHome = new HomePage();
                    this.NavigationService.Navigate(objHome);
                    //ds.Tables[0].Rows.Count=0;
                    dt.Rows.Clear();
                    
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
                conn.Close();
                cmd.Dispose();
                //return ds.Tables[0];
            }
            catch
            {
                MessageBox.Show("Exception");
            }
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtLoginID.Text = "";
            txtPassword.Text = "";
        }

        
    }
}
