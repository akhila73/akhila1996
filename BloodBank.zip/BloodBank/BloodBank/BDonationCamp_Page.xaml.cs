﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entity_Layer;
using BL_Layer;

namespace BloodBank
{
    /// <summary>
    /// Interaction logic for BDonationCamp_Page.xaml
    /// </summary>
    public partial class BDonationCamp_Page : Page
    {
        public BDonationCamp_Page()
        {
            InitializeComponent();
        }

        private void btnAddCamp_Click(object sender, RoutedEventArgs e)
        {
            Entities.Camp camp = new Entities.Camp();
            camp.CampId = txtCampId.Text;
            camp.CampName = txtCampName.Text;
            camp.CampAddress = txtAddress.Text;
            camp.CampCity = txtCity.Text;
            camp.BloodBank = txtBBank.Text;
            camp.CampStartDate = Convert.ToDateTime(txtCampStart.Text);
            camp.CampEndDate = Convert.ToDateTime(txtCampStart.Text);
            BLLClass bLLClass = new BLLClass();
            bLLClass.AddCampBLL(camp);
        }
    }
}
