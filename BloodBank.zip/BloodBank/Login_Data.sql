CREATE PROCEDURE InsertIntoLogin_Data
@User_Id varchar(50),@Password varchar(50)
AS
BEGIN
insert into Login_Data values(@User_Id, @Password)
END
GO

exec InsertIntoLogin_Data "admin","admin"
exec InsertIntoLogin_Data "static","static"
