﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity_Layer
{
    public class Entities
    {
        public class BloodDonor
        {
            private string bDonorId;
            public string BDonorId
            {
                get { return bDonorId; }
                set { bDonorId = value; }
            }
            private string firstName;
            public string Firstname
            {
                get { return firstName; }
                set { firstName = value; }
            }
            private string lastname;
            public string LastName
            {
                get { return lastname; }
                set { lastname = value; }
            }
            private string address;
            public string Address
            {
                get { return address; }
                set { address = value; }
            }
            private string city;
            public string City
            {
                get { return city; }
                set { city = value; }
            }
            private string mobileNo;
            public string MobileNo
            {
                get { return mobileNo; }
                set { mobileNo = value; }
            }
            private string bloodGroup;
            public string BloodGroup
            {
                get { return bloodGroup; }
                set { bloodGroup = value; }
            }
        }
        public class Camp
        {

            private string campId;
            public string CampId
            {
                get { return campId; }
                set { campId = value; }
            }
            private string campAddress;
            public string CampAddress
            {
                get { return campAddress; }
                set { campAddress = value; }
            }
            private string campCity;
            public string CampCity
            {
                get { return campCity; }
                set { campCity = value; }
            }
            private string campName;
            public string CampName
            {
                get { return campName; }
                set { campName = value; }
            }
            private string bloodBank;
            public string BloodBank
            {
                get { return bloodBank; }
                set { bloodBank = value; }
            }
            private DateTime campStartDate;
            public DateTime CampStartDate
            {
                get { return campStartDate; }
                set { campStartDate = value; }
            }
            private DateTime campEndDate;
            public DateTime CampEndDate
            {
                get { return campEndDate; }
                set { campEndDate = value; }
            }
        }
    }
}
